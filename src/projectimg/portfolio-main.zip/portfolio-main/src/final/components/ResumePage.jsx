import React from 'react'

const ResumePage = () => {
  return (
    <div>ResumePage</div>
  )
}

export default ResumePage